#include "config.h"
class Score {
private:
	int no;
	char name[11];
	int cpp, java, jsp, total;
	double average;
public:


};
	



void main() {


}