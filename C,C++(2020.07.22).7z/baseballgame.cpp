#include "config.h"
#include <time.h>

void main() {

	int baseball[9] ;

	for (int i = 0; i < 9; i++) {
		baseball[i] = i + 1;
		printf("data[%d] = %d\n", i, baseball[i]);
	}
	printf("\n==========���� ��============\n");

	srand((unsigned)time(NULL));
	for (int i = 0; i < 100; i++) {
		int r = (rand() % 9) + 1;
		int temp = baseball[0];
		baseball[0] = baseball[r];
		baseball[r] = temp;
	}
	for (int i = 0; i < 9; i++) {
		printf("2%d", baseball[i]);
		}
	printf("\n==========���� ��============\n");
}