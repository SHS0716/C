#include "config.h"

struct Money {
	int pm[10];
	int tm[10];
	char n[11];
	int p;
};


void main() {
	struct Money money1;

	while (true) {
		printf("�̸��� ����� �Է��ϼ��� : ");
		scanf_s("%s", money1.n, sizeof(money1.n));
		if (strcmp(money1.n, "QUIT") == 0) {
			break;
		}
		scanf_s("%d", &money1.p);
		printf("%s %d\n", &money1.n, &money1.p);

		int t = money1.p;
		int m = 50000;
		int sw = 1;

		for (int k = 0; k < 10; k++) {
			money1.pm[k] = t / m;
			t %= m;
			if (sw == 1) {
				m /= 5;
				sw = 0;
			}
			else {
				m /= 2;
				sw = 1;
			}

		}
		printf(" �̸�   ����� 50000 10000  5000  1000   500   100    50    10     5     1\n");
		printf("%6s %7d", money1.n, money1.p);

		for (int k = 0; k < 10; k++) {
			printf("%6d", money1.pm[k]);
			money1.tm[k] += money1.pm[k];
		}
		printf("\n");

	}

	printf("==========================================================================\n");
	printf(" �̸�   ����� 50000 10000  5000  1000   500   100    50    10     5     1\n");
	printf("��ü ȭ�� �ż�");
	for (int k = 0; k < 10; k++) {
		printf("%6d", money1.tm[k]);

	}
	printf("\n");
}
